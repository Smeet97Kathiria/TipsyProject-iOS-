//
//  ViewController.swift
//  TipsyProject
//
//  Created by Smeet Kathiria on 3/13/20.
//  Copyright © 2020 Smeet Kathiria. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var tip = 0.10
    var numberOfPeople = 2
    var billTotal = 0.0
    var finalResult = "0.0"
    
    
    @IBOutlet weak var splitNumberLabel: UILabel!
  
    @IBAction func tipChanged(_ sender: UIButton) {
        billTextField.endEditing(true)
       zeroPctButton.isSelected = false
       tenPctButton.isSelected = false
       twentyPctButton.isSelected = false
         sender.isSelected = true
        
        let buttonTitle = sender.currentTitle!
        let buttonTitleMinusPercentSign =  String(buttonTitle.dropLast())
        let buttonTitleAsANumber = Double(buttonTitleMinusPercentSign)!
        tip = buttonTitleAsANumber / 100

    }
    @IBOutlet weak var twentyPctButton: UIButton!
    @IBOutlet weak var tenPctButton: UIButton!
    @IBOutlet weak var zeroPctButton: UIButton!
    @IBOutlet weak var billTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        billTextField.addDoneButtonOnKeyboard()
        // Do any additional setup after loading the view.
    }

 
    @IBAction func calculateButtonPressed(_ sender: UIButton) {
        let bill = billTextField.text!
              if bill != "" {
                  billTotal = Double(bill)!
                  let result = billTotal * (1 + tip) / Double(numberOfPeople)
                  finalResult = String(format: "%.2f", result)
              }
              self.performSegue(withIdentifier: "resultVC", sender: self)
    }
    
    @IBAction func stepperValueChanged(_ sender: UIStepper) {
        splitNumberLabel.text = String(format: "%.0f", sender.value)
        numberOfPeople = Int(sender.value)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           
           if segue.identifier == "resultVC" {
               
               let destinationVC = segue.destination as! ResultViewController
               destinationVC.result = finalResult
               destinationVC.tip = Int(tip * 100)
               destinationVC.split = numberOfPeople
           }
       }
}

extension UITextField{
    
    @IBInspectable var doneAccessory: Bool{
        get{
            return self.doneAccessory
        }
        set (hasDone) {
            if hasDone{
                addDoneButtonOnKeyboard()
            }
        }
    }
    
    func addDoneButtonOnKeyboard()
    {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = .default
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.doneButtonAction))
        
        let items = [flexSpace, done]
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        
        self.inputAccessoryView = doneToolbar
    }
    
    @objc func doneButtonAction()
    {
        self.resignFirstResponder()
    }
}
